package Cinema.database;

import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailUtility {

    private static final String SMTP_HOST = "smtp.gmail.com";
    private static final int SMTP_PORT = 587; // Chuyển sang 587 để dùng STARTTLS
    private static final String EMAIL_USERNAME = "lckchaser1007@gmail.com";
    private static final String EMAIL_PASSWORD = "mvuq rmzq fhwc mqxk"; 

    public static String validOtpCode;
    public static long otpCreationTime; // Lưu thời gian tạo OTP (dưới dạng milliseconds)
    private static final long OTP_VALID_DURATION = 60 * 1000; // 60 giây (đơn vị: milliseconds)

    public static Boolean sendVerificationEmail(String emailAddress) {
        String otp = generateOTP();
        validOtpCode = otp;
        otpCreationTime = System.currentTimeMillis(); // Lưu thời gian tạo OTP
        String message = "Mã của bạn : " + otp + "\nMã này chỉ có hiệu lực trong 60 giây.";
        String subject = "MÃ XÁC THỰC OTP";
        return sendEmail(message, subject, emailAddress);
    }

    private static String generateOTP() {
        return String.format("%06d", (int) (Math.random() * 1000000));
    }

    public static Boolean sendEmail(String message, String subject, String to) {
        try {
            Properties props = new Properties();
            props.put("mail.smtp.host", SMTP_HOST);
            props.put("mail.smtp.port", SMTP_PORT);
            props.put("mail.smtp.auth", "true");
            props.put("mail.smtp.starttls.enable", "true");
            props.put("mail.smtp.ssl.protocols", "TLSv1.2");

            Session session = Session.getInstance(props, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(EMAIL_USERNAME, EMAIL_PASSWORD);
                }
            });

            MimeMessage msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(EMAIL_USERNAME));
            msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            msg.setSubject(subject);
            msg.setText(message);

            Transport.send(msg);
            System.out.println("Email sent successfully.");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Phương thức kiểm tra xem OTP có còn hiệu lực không
    public static boolean isOtpValid(String inputOtp) {
        // Kiểm tra xem OTP có khớp không
        if (validOtpCode == null || !validOtpCode.equals(inputOtp)) {
            return false; // OTP không khớp
        }

        // Kiểm tra thời gian hiệu lực
        long currentTime = System.currentTimeMillis();
        long elapsedTime = currentTime - otpCreationTime;

        if (elapsedTime > OTP_VALID_DURATION) {
            // Nếu đã quá 60 giây, OTP không còn hiệu lực
            validOtpCode = null; // Xóa OTP để không thể sử dụng lại
            return false;
        }

        return true; // OTP còn hiệu lực
    }
}