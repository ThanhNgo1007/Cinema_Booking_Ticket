package Cinema.database;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import Cinema.util.User;

import java.io.*;
import java.nio.file.Files;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JSONUtility {

    // Đường dẫn tài nguyên nhúng trong .jar
    private static final String RESOURCE_PATH_USERDATA = "Cinema/database/userdata.json";
    private static final String RESOURCE_PATH_ADMINDATA = "Cinema/database/admindata.json";
    private static final String RESOURCE_PATH_MOVIEDATA = "Cinema/database/moviedata.json";

    // Đường dẫn file lưu trữ bên ngoài (thư mục hiện tại)
    private static final String EXTERNAL_PATH_USERDATA = "userdata.json";
    private static final String EXTERNAL_PATH_ADMINDATA = "admindata.json";
    private static final String EXTERNAL_PATH_MOVIEDATA = "moviedata.json";

    // Lấy tài nguyên từ .jar
    private static InputStream getResourceAsStream(String resourcePath) {
        return JSONUtility.class.getClassLoader().getResourceAsStream(resourcePath);
    }

    // Đọc dữ liệu từ file bên ngoài hoặc tài nguyên nhúng
    private static String readJsonFile(String externalPath, String resourcePath) throws IOException {
        File externalFile = new File(externalPath);
        if (externalFile.exists()) {
            return new String(Files.readAllBytes(externalFile.toPath()));
        } else {
            try (InputStream is = getResourceAsStream(resourcePath)) {
                if (is == null) throw new IOException("Resource not found: " + resourcePath);
                return new String(is.readAllBytes());
            }
        }
    }

    // Ghi dữ liệu ra file bên ngoài
    private static void writeJsonFile(String externalPath, String jsonString) throws IOException {
        try (FileWriter writer = new FileWriter(externalPath)) {
            writer.write(jsonString);
        }
    }

    // Lưu thông tin người dùng từ ResultSet
    public static void storeUserDataFromResultSet(ResultSet rs) throws IOException, SQLException {
        int userId = rs.getInt("id");
        String phoneNumber = rs.getString("phone_num");
        String firstName = rs.getString("first_name");
        String lastName = rs.getString("last_name");
        String cityName = rs.getString("city");
        String userEmail = rs.getString("email");
        String quan = rs.getString("quan");
        String phuong = rs.getString("phuong");
        String homeAddress = rs.getString("homeAddress");

        if (phoneNumber == null || phoneNumber.isEmpty()) phoneNumber = "";
        if (firstName == null || firstName.isEmpty()) firstName = "";
        if (lastName == null || lastName.isEmpty()) lastName = "";
        if (cityName == null || cityName.isEmpty()) cityName = "";
        if (userEmail == null || userEmail.isEmpty()) userEmail = "";
        if (quan == null || quan.isEmpty()) quan = "";
        if (phuong == null || phuong.isEmpty()) phuong = "";
        if (homeAddress == null || homeAddress.isEmpty()) homeAddress = "";

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        User user = new User(userId, firstName, lastName, userEmail, phoneNumber, cityName, quan, phuong, homeAddress);
        String jsonString = gson.toJson(user);

        writeJsonFile(EXTERNAL_PATH_USERDATA, jsonString);
    }

    // Lưu thông tin admin từ ResultSet
    public static void storeAdminDataFromResultSet(ResultSet rs) throws IOException, SQLException {
        int adminId = rs.getInt("id");
        String phoneNumber = rs.getString("phone_num");
        String firstName = rs.getString("first_name");
        String lastName = rs.getString("last_name");
        String cityName = rs.getString("city");
        String adminEmail = rs.getString("email");
        String quan = rs.getString("quan");
        String huyen = rs.getString("phuong");
        String homeAddress = rs.getString("homeAddress");

        if (phoneNumber == null || phoneNumber.isEmpty()) phoneNumber = "";
        if (firstName == null || firstName.isEmpty()) firstName = "";
        if (lastName == null || lastName.isEmpty()) lastName = "";
        if (cityName == null || cityName.isEmpty()) cityName = "";
        if (adminEmail == null || adminEmail.isEmpty()) adminEmail = "";
        if (quan == null || quan.isEmpty()) quan = "";
        if (huyen == null || huyen.isEmpty()) huyen = "";
        if (homeAddress == null || homeAddress.isEmpty()) homeAddress = "";

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        User admin = new User(adminId, firstName, lastName, adminEmail, phoneNumber, cityName, quan, huyen, homeAddress);
        String jsonString = gson.toJson(admin);

        writeJsonFile(EXTERNAL_PATH_ADMINDATA, jsonString);
    }

    // Lưu thông tin người dùng trực tiếp từ tham số
    public static void storeUserData(int userId, String firstName, String lastName, String email, String phoneNumber, String cityName, String quan, String phuong, String homeAddress) throws IOException {
        if (phoneNumber == null || phoneNumber.isEmpty()) phoneNumber = "";
        if (firstName == null || firstName.isEmpty()) firstName = "";
        if (lastName == null || lastName.isEmpty()) lastName = "";
        if (cityName == null || cityName.isEmpty()) cityName = "";
        if (email == null || email.isEmpty()) email = "";
        if (quan == null || quan.isEmpty()) quan = "";
        if (phuong == null || phuong.isEmpty()) phuong = "";
        if (homeAddress == null || homeAddress.isEmpty()) homeAddress = "";

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        User user = new User(userId, firstName, lastName, email, phoneNumber, cityName, quan, phuong, homeAddress);
        String jsonString = gson.toJson(user);

        writeJsonFile(EXTERNAL_PATH_USERDATA, jsonString);
    }

    // Kiểm tra người dùng đã đăng nhập chưa
    public static boolean userIsLoggedIn() {
        try {
            String jsonString = readJsonFile(EXTERNAL_PATH_USERDATA, RESOURCE_PATH_USERDATA);
            JsonObject jsonObject = JsonParser.parseString(jsonString).getAsJsonObject();
            return jsonObject.has("userId") && !jsonObject.get("userId").isJsonNull() && jsonObject.has("email")
                    && !jsonObject.get("email").isJsonNull() && !jsonObject.get("userId").getAsString().isEmpty()
                    && !jsonObject.get("email").getAsString().isEmpty();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Xóa giá trị trong userdata.json
    public static boolean removeValuesAndSave() {
        try {
            String jsonString = readJsonFile(EXTERNAL_PATH_USERDATA, RESOURCE_PATH_USERDATA);
            JsonObject jsonObject = JsonParser.parseString(jsonString).getAsJsonObject();

            jsonObject.addProperty("userId", "");
            jsonObject.addProperty("email", "");
            jsonObject.addProperty("firstName", "");
            jsonObject.addProperty("lastName", "");
            jsonObject.addProperty("phoneNumber", "");
            jsonObject.addProperty("cityName", "");
            jsonObject.addProperty("quan", "");
            jsonObject.addProperty("phuong", "");
            jsonObject.addProperty("homeAddress", "");

            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            writeJsonFile(EXTERNAL_PATH_USERDATA, gson.toJson(jsonObject));
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Xóa giá trị trong admindata.json
    public static boolean removeValuesAndSaveAdmin() {
        try {
            String jsonString = readJsonFile(EXTERNAL_PATH_ADMINDATA, RESOURCE_PATH_ADMINDATA);
            JsonObject jsonObject = JsonParser.parseString(jsonString).getAsJsonObject();

            jsonObject.addProperty("userId", "");
            jsonObject.addProperty("email", "");
            jsonObject.addProperty("firstName", "");
            jsonObject.addProperty("lastName", "");
            jsonObject.addProperty("phoneNumber", "");
            jsonObject.addProperty("cityName", "");
            jsonObject.addProperty("quan", "");
            jsonObject.addProperty("phuong", "");
            jsonObject.addProperty("homeAddress", "");

            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            writeJsonFile(EXTERNAL_PATH_ADMINDATA, gson.toJson(jsonObject));
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Lấy dữ liệu người dùng
    public static User getUserData() {
        try {
            String jsonString = readJsonFile(EXTERNAL_PATH_USERDATA, RESOURCE_PATH_USERDATA);
            JsonObject jsonObject = JsonParser.parseString(jsonString).getAsJsonObject();

            int userId = jsonObject.has("userId") && !jsonObject.get("userId").isJsonNull() ? jsonObject.get("userId").getAsInt() : 0;
            String firstName = jsonObject.has("firstName") && !jsonObject.get("firstName").isJsonNull() ? jsonObject.get("firstName").getAsString() : "";
            String lastName = jsonObject.has("lastName") && !jsonObject.get("lastName").isJsonNull() ? jsonObject.get("lastName").getAsString() : "";
            String email = jsonObject.has("email") && !jsonObject.get("email").isJsonNull() ? jsonObject.get("email").getAsString() : "";
            String phoneNumber = jsonObject.has("phoneNumber") && !jsonObject.get("phoneNumber").isJsonNull() ? jsonObject.get("phoneNumber").getAsString() : "";
            String cityName = jsonObject.has("cityName") && !jsonObject.get("cityName").isJsonNull() ? jsonObject.get("cityName").getAsString() : "";
            String quan = jsonObject.has("quan") && !jsonObject.get("quan").isJsonNull() ? jsonObject.get("quan").getAsString() : "";
            String huyen = jsonObject.has("phuong") && !jsonObject.get("phuong").isJsonNull() ? jsonObject.get("phuong").getAsString() : "";
            String homeAddress = jsonObject.has("homeAddress") && !jsonObject.get("homeAddress").isJsonNull() ? jsonObject.get("homeAddress").getAsString() : "";
            return new User(userId, firstName, lastName, email, phoneNumber, cityName, quan, huyen, homeAddress);
        } catch (IOException e) {
            System.err.println("Lỗi lấy dữ liệu người dùng: " + e.getMessage());
            return null;
        }
    }

    // Lấy tên người dùng
    public static String getUserFirstName() {
        try {
            String jsonString = readJsonFile(EXTERNAL_PATH_USERDATA, RESOURCE_PATH_USERDATA);
            JsonObject jsonObject = JsonParser.parseString(jsonString).getAsJsonObject();
            return jsonObject.get("firstName").getAsString();
        } catch (IOException e) {
            System.out.println("Error getting user data: " + e.getMessage());
            return "Guest";
        }
    }

    // Lớp MovieData
    public static class MovieData {
        public String id;
        public int basePrice, totalPrice = 0, numberOfSeats = 0;
        public String name, timing, selected, screen;
        public String[] selectedSeats = {};

        public MovieData(String id, String name, String timing, int basePrice, String screen) {
            this.id = id;
            this.name = name;
            this.timing = timing;
            this.basePrice = basePrice;
            this.screen = screen;
        }
    }

    // Tạo file moviedata.json
    public void createMovieJson(String id_lichchieu, String movieName, String timing, String seatInfo, int basePrice, String screen) throws IOException {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        MovieData movieData = new MovieData(id_lichchieu, movieName, timing, basePrice, screen);
        movieData.totalPrice = 0;
        movieData.numberOfSeats = 0;
        movieData.selected = "";
        movieData.selectedSeats = new String[]{};

        writeJsonFile(EXTERNAL_PATH_MOVIEDATA, gson.toJson(movieData));
    }

    // Lấy dữ liệu phim
    public MovieData getMovieJson() {
        try {
            String jsonString = readJsonFile(EXTERNAL_PATH_MOVIEDATA, RESOURCE_PATH_MOVIEDATA);
            JsonObject jsonObject = JsonParser.parseString(jsonString).getAsJsonObject();

            MovieData movieData = new MovieData(
                jsonObject.get("id").getAsString(),
                jsonObject.get("name").getAsString(),
                jsonObject.get("timing").getAsString(),
                jsonObject.get("basePrice").getAsInt(),
                jsonObject.get("screen").getAsString()
            );
            movieData.totalPrice = jsonObject.get("totalPrice").getAsInt();
            movieData.numberOfSeats = jsonObject.has("numberOfSeats") ? jsonObject.get("numberOfSeats").getAsInt() : 0;
            movieData.selected = jsonObject.has("selected") ? jsonObject.get("selected").getAsString() : "";
            JsonArray selectedArr = jsonObject.getAsJsonArray("selectedSeats");
            movieData.selectedSeats = new String[selectedArr.size()];
            for (int i = 0; i < selectedArr.size(); i++) {
                movieData.selectedSeats[i] = selectedArr.get(i).getAsString();
            }
            return movieData;
        } catch (IOException e) {
            System.out.println("Error getting movie data: " + e.getMessage());
            return null;
        }
    }

    // Cập nhật dữ liệu phim
    public boolean updateMovieJson(String[] seats, int price) {
        try {
            String jsonString = readJsonFile(EXTERNAL_PATH_MOVIEDATA, RESOURCE_PATH_MOVIEDATA);
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            MovieData movieData = gson.fromJson(jsonString, MovieData.class);

            movieData.selected = String.join(", ", seats);
            movieData.selectedSeats = seats;
            movieData.totalPrice = price;
            movieData.numberOfSeats = seats.length;

            writeJsonFile(EXTERNAL_PATH_MOVIEDATA, gson.toJson(movieData));
            return true;
        } catch (IOException e) {
            System.out.println("Error updating movie data: " + e.getMessage());
            return false;
        }
    }

    // Xóa dữ liệu phim
    public boolean clearMovieData() {
        try {
            String jsonString = readJsonFile(EXTERNAL_PATH_MOVIEDATA, RESOURCE_PATH_MOVIEDATA);
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            MovieData movieData = gson.fromJson(jsonString, MovieData.class);

            movieData.selected = "";
            movieData.selectedSeats = new String[]{};
            movieData.totalPrice = 0;
            movieData.numberOfSeats = 0;

            writeJsonFile(EXTERNAL_PATH_MOVIEDATA, gson.toJson(movieData));
            return true;
        } catch (IOException e) {
            System.out.println("Error clearing movie data: " + e.getMessage());
            return false;
        }
    }

    // Cập nhật giá phim
    public boolean updateMoviePrice(int newTotalPrice) {
        try {
            String jsonString = readJsonFile(EXTERNAL_PATH_MOVIEDATA, RESOURCE_PATH_MOVIEDATA);
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            MovieData movieData = gson.fromJson(jsonString, MovieData.class);

            movieData.totalPrice = newTotalPrice;

            writeJsonFile(EXTERNAL_PATH_MOVIEDATA, gson.toJson(movieData));
            return true;
        } catch (IOException e) {
            System.out.println("Error updating movie price: " + e.getMessage());
            return false;
        }
    }
}