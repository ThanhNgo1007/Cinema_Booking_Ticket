package Cinema.util;

public class Ward {
    private String name;
    private int code;
    private String division_type;

    public String getName() { return name; }
    public int getCode() { return code; }
    public String getDivisionType() { return division_type; }
}