package Cinema.controller;

public class Event1_Controller extends BaseEventController{

}